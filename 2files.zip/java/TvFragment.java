package com.example.iptvplayer;

import android.content.Context;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.DeviceInfo;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.Timeline;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.VideoSize;
import androidx.media3.common.text.Cue;
import androidx.media3.common.text.CueGroup;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

// Imports que faltavam
import androidx.media3.common.Player.Events;
import androidx.media3.common.Player.Commands;
import androidx.media3.common.Player.PositionInfo;
import androidx.media3.common.Metadata;

import com.example.iptvplayer.adapter.ChannelAdapter;
import com.example.iptvplayer.adapter.LiveCategoryAdapter;
import com.example.iptvplayer.data.Channel;
import com.example.iptvplayer.parser.M3uParser;
import com.google.android.material.textfield.TextInputEditText;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TvFragment extends Fragment implements ChannelAdapter.OnChannelClickListener {

    private static final String TAG = "TvFragment";

    private RecyclerView recyclerViewChannels;
    private RecyclerView recyclerViewCategories;
    private ChannelAdapter channelAdapter;
    private TextInputEditText searchEditText;
    private List<Channel> allChannels = new ArrayList<>();
    private DownloadReceiver downloadReceiver;

    private PlayerView playerView;
    private ExoPlayer player;
    private ProgressBar playerProgressBar;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_tv, container, false);

        recyclerViewChannels = root.findViewById(R.id.recycler_view_channels);
        recyclerViewCategories = root.findViewById(R.id.recycler_view_categories);
        searchEditText = root.findViewById(R.id.search_edit_text);
        playerView = root.findViewById(R.id.player_view);
        playerProgressBar = root.findViewById(R.id.player_progress_bar);

        recyclerViewChannels.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewCategories.setLayoutManager(new LinearLayoutManager(getContext()));

        initializePlayer();

        downloadReceiver = new DownloadReceiver(this);
        IntentFilter filter = new IntentFilter(DownloadService.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requireActivity().registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            requireActivity().registerReceiver(downloadReceiver, filter);
        }

        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (channelAdapter != null) {
                    channelAdapter.filterList(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        loadInitialData();
        return root;
    }

    private void initializePlayer() {
        player = new ExoPlayer.Builder(requireContext()).build();
        playerView.setPlayer(player);

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_BUFFERING) {
                    showLoading(true);
                } else {
                    showLoading(false);
                }
            }

            @Override
            public void onPlayerError(@NonNull PlaybackException error) {
                Log.e(TAG, "Erro no ExoPlayer: " + error.getMessage(), error);
                showLoading(false);
                Toast.makeText(getContext(), "Erro ao reproduzir: " + error.getErrorCodeName(), Toast.LENGTH_LONG).show();
            }

            // Implementações vazias para satisfazer o compilador
            @Override
            public void onEvents(@NonNull Player player, @NonNull Events events) {}
            @Override
            public void onTimelineChanged(@NonNull Timeline timeline, int reason) {}
            @Override
            public void onMediaItemTransition(@Nullable MediaItem mediaItem, int reason) {}
            @Override
            public void onTracksChanged(@NonNull Tracks tracks) {}
            @Override
            public void onMediaMetadataChanged(@NonNull MediaMetadata mediaMetadata) {}
            @Override
            public void onPlaylistMetadataChanged(@NonNull MediaMetadata mediaMetadata) {}
            @Override
            public void onIsLoadingChanged(boolean isLoading) {}
            @Override
            public void onAvailableCommandsChanged(@NonNull Commands availableCommands) {}
            @Override
            public void onTrackSelectionParametersChanged(@NonNull TrackSelectionParameters parameters) {}
            @Override
            public void onPlayWhenReadyChanged(boolean playWhenReady, int reason) {}
            @Override
            public void onPlaybackSuppressionReasonChanged(int playbackSuppressionReason) {}
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {}
            @Override
            public void onRepeatModeChanged(int repeatMode) {}
            @Override
            public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {}
            @Override
            public void onPlayerErrorChanged(@Nullable PlaybackException error) {}
            @Override
            public void onPositionDiscontinuity(@NonNull PositionInfo oldPosition, @NonNull PositionInfo newPosition, int reason) {}
            @Override
            public void onPlaybackParametersChanged(@NonNull PlaybackParameters playbackParameters) {}
            @Override
            public void onSeekBackIncrementChanged(long seekBackIncrementMs) {}
            @Override
            public void onSeekForwardIncrementChanged(long seekForwardIncrementMs) {}
            @Override
            public void onMaxSeekToPreviousPositionChanged(long maxSeekToPreviousPositionMs) {}
            @Override
            public void onAudioSessionIdChanged(int audioSessionId) {}
            @Override
            public void onAudioAttributesChanged(@NonNull AudioAttributes audioAttributes) {}
            @Override
            public void onVolumeChanged(float volume) {}
            @Override
            public void onSkipSilenceEnabledChanged(boolean skipSilenceEnabled) {}
            @Override
            public void onDeviceInfoChanged(@NonNull DeviceInfo deviceInfo) {}
            @Override
            public void onDeviceVolumeChanged(int volume, boolean muted) {}
            @Override
            public void onVideoSizeChanged(@NonNull VideoSize videoSize) {}
            @Override
            public void onSurfaceSizeChanged(int width, int height) {}
            @Override
            public void onRenderedFirstFrame() {}
            @Override
            public void onCues(@NonNull List<Cue> cues) {}
            @Override
            public void onCues(@NonNull CueGroup cueGroup) {}
        });
    }

    @Override
    public void onChannelClick(Channel channel) {
        Log.d(TAG, "onChannelClick chamado para: " + channel.getName());
        if (player != null && channel.getStreamUrl() != null && !channel.getStreamUrl().isEmpty()) {
            showLoading(true);
            String streamUrl = channel.getStreamUrl();
            Log.d(TAG, "URL do Stream: " + streamUrl);
            Uri videoUri = Uri.parse(streamUrl);
            MediaItem mediaItem = new MediaItem.Builder().setUri(videoUri).build();
            player.setMediaItem(mediaItem);
            player.prepare();
            player.play();
        } else {
            Log.w(TAG, "Player não está pronto ou a URL do canal é nula/vazia.");
            Toast.makeText(getContext(), "Não foi possível reproduzir o canal.", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadInitialData() {
        fetchXtreamCredentials(new CredentialsCallback() {
            @Override
            public void onCredentialsReceived(String baseUrl, String username, String password) {
                fetchLiveCategoriesFromApi(baseUrl, username, password, new CategoryCallback() {
                    @Override
                    public void onCategoriesReceived(Map<String, String> categoryMap) {
                        fetchLiveChannelsFromApi(baseUrl, username, password, null);
                    }

                    @Override
                    public void onCategoryFailure(String error) {
                        if (getActivity() != null) {
                            getActivity().runOnUiThread(() -> {
                                Toast.makeText(getContext(), "Falha ao carregar categorias: " + error, Toast.LENGTH_LONG).show();
                                showLoading(false);
                            });
                        }
                        fetchLiveChannelsFromApi(baseUrl, username, password, null);
                    }
                });
            }

            @Override
            public void onCredentialsFailure(String error) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getContext(), "Falha ao obter credenciais: " + error, Toast.LENGTH_LONG).show();
                        showLoading(false);
                    });
                }
            }
        });
    }

    private void showLoading(boolean isLoading) {
        if (playerProgressBar != null) {
            playerProgressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        }
    }

    public void parseM3uFile(String filePath) {
        executor.execute(() -> {
            try {
                File file = new File(filePath);
                BufferedReader reader = new BufferedReader(new FileReader(file));
                List<Channel> parsedChannels = M3uParser.parse(reader);
                reader.close();

                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        allChannels.clear();
                        allChannels.addAll(parsedChannels);
                        channelAdapter = new ChannelAdapter(getContext(), allChannels, this);
                        recyclerViewChannels.setAdapter(channelAdapter);
                        showLoading(false);
                        Toast.makeText(getContext(), "M3U carregado com sucesso!", Toast.LENGTH_SHORT).show();
                    });
                }
            } catch (IOException e) {
                Log.e("TvFragment", "Erro ao ler arquivo M3U", e);
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getContext(), "Erro ao carregar M3U: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        showLoading(false);
                    });
                }
            }
        });
    }

    private void fetchXtreamCredentials(CredentialsCallback callback) {
        XtreamLoginService loginService = new XtreamLoginService();
        loginService.getLoginData(new XtreamLoginService.LoginCallback() {
            @Override
            public void onSuccess(XtreamLoginService.XtreamAccount account) {
                String serverUrl = account.server;
                if (!serverUrl.toLowerCase().startsWith("http://") && !serverUrl.toLowerCase().startsWith("https://")) {
                    serverUrl = "http://" + serverUrl;
                }
                callback.onCredentialsReceived(serverUrl, account.username, account.password);
            }

            @Override
            public void onFailure(String error) {
                callback.onCredentialsFailure(error);
            }
        });
    }

    private void fetchLiveCategoriesFromApi(String baseUrl, String username, String password, CategoryCallback callback) {
        executor.execute(() -> {
            XtreamApiService apiService = new XtreamApiService(baseUrl, username, password);
            apiService.fetchLiveStreamCategories(new XtreamApiService.XtreamApiCallback<XtreamApiService.CategoryInfo>() {
                @Override
                public void onSuccess(List<XtreamApiService.CategoryInfo> data) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            Map<String, String> categoryMap = new java.util.HashMap<>();
                            for (XtreamApiService.CategoryInfo categoryInfo : data) {
                                categoryMap.put(categoryInfo.id, categoryInfo.name);
                            }
                            callback.onCategoriesReceived(categoryMap);
                            LiveCategoryAdapter categoryAdapter = new LiveCategoryAdapter(getContext(), data, categoryId -> fetchLiveChannelsFromApi(baseUrl, username, password, categoryId));
                            recyclerViewCategories.setAdapter(categoryAdapter);
                        });
                    }
                }

                @Override
                public void onFailure(String error) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(() -> callback.onCategoryFailure(error));
                    }
                }
            });
        });
    }

    private void fetchLiveChannelsFromApi(String baseUrl, String username, String password, @Nullable String categoryId) {
        showLoading(true);
        executor.execute(() -> {
            XtreamApiService apiService = new XtreamApiService(baseUrl, username, password);
            apiService.fetchLiveStreams(new XtreamApiService.XtreamApiCallback<Channel>() {
                @Override
                public void onSuccess(List<Channel> data) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            allChannels.clear();
                            allChannels.addAll(data);
                            channelAdapter = new ChannelAdapter(getContext(), allChannels, TvFragment.this);
                            recyclerViewChannels.setAdapter(channelAdapter);
                            showLoading(false);
                        });
                    }
                }

                @Override
                public void onFailure(String error) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            Toast.makeText(getContext(), "Falha ao carregar canais: " + error, Toast.LENGTH_LONG).show();
                            showLoading(false);
                        });
                    }
                }
            });
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (player != null) {
            player.release();
            player = null;
        }
        if (downloadReceiver != null) {
            requireActivity().unregisterReceiver(downloadReceiver);
        }
    }

    public interface CredentialsCallback {
        void onCredentialsReceived(String baseUrl, String username, String password);
        void onCredentialsFailure(String error);
    }

    public interface CategoryCallback {
        void onCategoriesReceived(Map<String, String> categoryMap);
        void onCategoryFailure(String error);
    }

    public interface ChannelCallback {
        void onChannelsReceived(List<Channel> channels);
        void onChannelsFailure(String error);
    }
}