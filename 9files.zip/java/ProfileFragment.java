package com.example.iptvplayer;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProfileFragment extends Fragment {

    private TextInputEditText xtreamUrlEditText;
    private MaterialButton sendXtreamButton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        xtreamUrlEditText = view.findViewById(R.id.xtream_url_edit_text);
        sendXtreamButton = view.findViewById(R.id.send_xtream_button);

        sendXtreamButton.setOnClickListener(v -> {
            String xtreamUrl = xtreamUrlEditText.getText().toString();
            if (xtreamUrl.isEmpty()) {
                Toast.makeText(getContext(), "Por favor, insira a URL da Lista Xtream Codes.", Toast.LENGTH_SHORT).show();
                return;
            }
            sendXtreamData(xtreamUrl);
        });

        return view;
    }

    private void sendXtreamData(String urlString) {
        new Thread(() -> {
            try {
                // Extract components from the URL
                Pattern pattern = Pattern.compile("^(https?://[^/]+)/get\\.php\\?username=([^&]+)&password=([^&]+)&type=m3u_plus&output=ts$");
                Matcher matcher = pattern.matcher(urlString);

                if (!matcher.matches()) {
                    showToast("URL inválida. Certifique-se de que está no formato correto.");
                    return;
                }

                String server = matcher.group(1);
                String username = matcher.group(2);
                String password = matcher.group(3);

                // Create JSON object
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", UUID.randomUUID().toString().replace("-", ""));
                jsonObject.put("server", server);
                jsonObject.put("username", username);
                jsonObject.put("password", password);
                jsonObject.put("added_at", new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date()));
                jsonObject.put("last_validated", new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date()));

                JSONArray jsonArray = new JSONArray();
                jsonArray.put(jsonObject);

                // Send data to the PHP server
                URL url = new URL("http://mybrasiltv.x10.mx/data.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setRequestProperty("Accept", "application/json");
                conn.setDoOutput(true);

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonArray.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    showToast("Lista Xtream Codes enviada com sucesso!");
                } else {
                    showToast("Erro ao enviar lista: " + responseCode);
                }

            } catch (Exception e) {
                e.printStackTrace();
                showToast("Erro: " + e.getMessage());
            }
        }).start();
    }

    private void showToast(String message) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(() -> Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show());
        }
    }
}


